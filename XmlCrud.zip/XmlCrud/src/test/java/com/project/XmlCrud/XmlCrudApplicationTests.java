package com.project.XmlCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
