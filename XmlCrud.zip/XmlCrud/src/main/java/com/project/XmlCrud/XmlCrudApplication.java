package com.project.XmlCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlCrudApplication.class, args);
	}

}
